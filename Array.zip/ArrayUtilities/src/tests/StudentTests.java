package tests;

import static org.junit.Assert.*;

import org.junit.Test;

import sysImplementation.Utilities;

public class StudentTests {

	@Test
	public void testGetArrStr() {
		char sep = ',';
		int [] arr=new int[3];
		arr[0]=1;
		arr[1]=2;
		arr[2]=4;
		String ans = Utilities.getArrayString​(arr,sep);
		System.out.println(ans);
		assertEquals("1,2,4",ans);
	}
	@Test
	public void testGetInst() {
		int [] arr = new int [6];
		arr[0]=1;
		arr[1]=2;
		arr[2]=4;
		arr[3]=7;
		arr[4]=9;
		arr[5]=15;
		int upperLimit=9;
		int lowerLimit=3;
		int ans = Utilities.getInstances​(arr,lowerLimit,upperLimit);
		assertEquals(3,ans);
		
		
	}
	@Test
	public void testRight() {
		int [] arr = new int [6];
		int [] exp= {15,1,2,4,7,9};
		arr[0]=1;
		arr[1]=2;
		arr[2]=4;
		arr[3]=7;
		arr[4]=9;
		arr[5]=15;
		
		Utilities.right(arr);
		assertArrayEquals(exp,arr);
	}
	@Test
	public void testLeft() {
		int [] arr = new int [6];
		int [] exp= {2,4,7,9,15,1};
		arr[0]=1;
		arr[1]=2;
		arr[2]=4;
		arr[3]=7;
		arr[4]=9;
		arr[5]=15;
		
		Utilities.left(arr);
		assertArrayEquals(exp,arr);
	}
	
	
	
	@Test
	public void testRot() {
		boolean rot = true;
		int [] arr = new int [6];
		int [] exp= {4,7,9,15,1,2};
		arr[0]=1;
		arr[1]=2;
		arr[2]=4;
		arr[3]=7;
		arr[4]=9;
		arr[5]=15;
		
		Utilities.rotate​(arr,rot,2);
		assertArrayEquals(exp,arr);
	
		
		
	}
	@Test
	public void testLonger() {
		
		StringBuffer[] buff = new StringBuffer[5];
		buff[0]=new StringBuffer("hello");
		buff[1]=new StringBuffer("hey");
		buff[2]=new StringBuffer("ahola");
		buff[3]=new StringBuffer("hola");
		buff[4]=new StringBuffer("desole");
		
		StringBuffer[] buff2 = new StringBuffer[3];
		buff2[0]=new StringBuffer("hello");
	
		buff2[1]=new StringBuffer("ahola");
		
		buff2[2]=new StringBuffer("desole");
		StringBuffer[] ans =Utilities.getArrayStringsLongerThan​(buff,4);
	
		String answer = "hello,ahola,desole,";
		String ans2 = "";
		for(StringBuffer i: ans) {
			ans2 = ans2 + i + ",";
		}
		assertEquals(ans2, answer);
	}
		
	@Test
	public void testLonger2() {
		StringBuffer[] buff = new StringBuffer[0];
		
		StringBuffer[] buff2 = new StringBuffer[0];
		StringBuffer[]ans = Utilities.getArrayStringsLongerThan​(buff,4);
		
		assertArrayEquals(buff2,ans);
		
		
	}
	@Test
	public void testLonger3() {
		
		
		StringBuffer[] buff2 = new StringBuffer[0];
		boolean work= true;
		try {
			StringBuffer[] order = null;
			 Utilities.getArrayStringsLongerThan​(order,4);
		}
		catch(IllegalArgumentException e){
			work=false;
			
			
		}
		assertFalse(work);
				
		
		
		
	}
	
	
	@Test
	public void testFilter() {
		int [] arr = new int [6];
		arr[0]=1;
		arr[1]=2;
		arr[2]=4;
		arr[3]=7;
		arr[4]=9;
		arr[5]=15;
		int upperLimit=9;
		int lowerLimit=3;
		int[] exp= {4,7,9};
		int[] ans = Utilities.filter​(arr,lowerLimit,upperLimit);
		assertArrayEquals(exp,ans);
		
	}
	


}
