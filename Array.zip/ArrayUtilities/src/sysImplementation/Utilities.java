package sysImplementation;

public class Utilities {
	public Utilities() {
	}

	public static java.lang.String getArrayString​(int[] array, char separator) {
		if (array == null) {
			throw new java.lang.IllegalArgumentException("No Good");
		}
		String ans = "";

		if (array.length == 0) {
			return ans;
		}

		for (int i = 0; i < array.length; i++) {
			ans = ans + Integer.toString(array[i]) + separator;
			}
		return ans.substring(0, ans.length() - 1);
		}



	public static int getInstances​(int[] array, int lowerLimit, int upperLimit) {
		if (array == null) {
			throw new java.lang.IllegalArgumentException("No Good");
		}
		int count = 0;

		for (int i = 0; i < array.length; i++) {

			if (array[i] >= lowerLimit && array[i] <= upperLimit) {
				count++;
			}
		}
		return count;
	}

	public static int[] filter​(int[] array, int lowerLimit, int upperLimit) {
		if (array == null || lowerLimit > upperLimit) {
			throw new java.lang.IllegalArgumentException("No Good");
		}
		int count = 0;
		int[] empty = new int[0];

		int[] ans = new int[getInstances​(array, lowerLimit, upperLimit)];
		for (int i = 0; i < array.length; i++) {

			if (array[i] >= lowerLimit && array[i] <= upperLimit) {
				ans[count] = array[i];
				count++;
			}
		}
		return ans;

	}

	public static void rotate​(int[] array, boolean leftRotation, int positions) {
		if (array == null) {
			throw new java.lang.IllegalArgumentException("No Good");
		}
		if (array.length < 2) {
			return;
		}
		if (leftRotation) {
			for (int i = 0; i < positions; i++) {
				left(array);
			}

		} else {
			for (int i = 0; i < positions; i++) {
				right(array);
			}

		}
	}

	public static void right(int[] array) {
		int[] Arr2 = new int[array.length];
		for (int i = 0; i < array.length; i++) {
			Arr2[i] = array[i];
		}

		for (int i = 1; i < array.length; i++) {
			array[i] = Arr2[i - 1];

		}
		array[0] = Arr2[array.length - 1];
	}

	public static void left(int[] array) {
		int[] Arr2 = new int[array.length];
		for (int i = 0; i < array.length; i++) {
			Arr2[i] = array[i];
		}

		for (int i = 0; i < array.length - 1; i++) {
			array[i] = Arr2[i + 1];

		}
		array[array.length - 1] = Arr2[0];
	}

	public static StringBuffer[] getArrayStringsLongerThan​(StringBuffer[] array, int length) {
		if (array == null) {
			throw new java.lang.IllegalArgumentException("No Good");
		}

		int count2 = 0;
		StringBuffer[] empty = new StringBuffer[0];
		if (array.length == 0) {
			return empty;
		}

		for (int i = 0; i < array.length; i++) {
			if (array[i].length() > length) {
				count2++;
			}

		}
		StringBuffer[] buff = new StringBuffer[count2];

		int count = 0;
		for (int i = 0; i < array.length; i++) {

			if (array[i].length() > length) {

				buff[count] = array[i];
				count++;
			}

		}
		return buff;
	}

}
